# Status and claim boundary

**Claim:** `Z(12,18;3,3)=108`.

**Internal verification status:** complete. A fresh standard-library replay checks the explicit lower-bound witness, both self-contained neighboring upper bounds, all four final branches, report invariants, checksums, and adversarial mutations.

**External status:** not peer-reviewed and not yet independently reproduced by an outside group. Priority and novelty remain subject to a full expert literature review.

**What is not being claimed:**

- no Lean/Coq/Isabelle formalization;
- no publication acceptance;
- no reliance on solver status, floating-point infeasibility, or incomplete search;
- no claim about general asymptotic Zarankiewicz bounds.
