#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
JOBS="${JOBS:-5}"
sha256sum -c --quiet SHA256SUMS.txt
python3 verify_all_exact.py --root . --jobs "$JOBS" --report reproduced_verification_report.json
python3 compare_report.py reports/reference_verification_report.json reproduced_verification_report.json
python3 mutation_tests.py
printf '%s\n' 'PACKAGE VERIFICATION PASSED'
