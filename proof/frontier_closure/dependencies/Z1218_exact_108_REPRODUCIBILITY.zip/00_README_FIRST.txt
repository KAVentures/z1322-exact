ARXIV / REPRODUCIBILITY BUNDLE
==============================

Main manuscript source: main.tex
Reference compiled paper: reference_pdf/Z1218_exact_108.pdf

To reproduce the complete computer-assisted proof from a clean extraction:

    ./verify.sh

The verification requires Python 3 and standard Unix tools only. The trusted
proof checker itself uses only the Python standard library and exact integer /
rational arithmetic. The generator scripts under generators/ are included for
provenance but are not part of the trusted proof base.

A successful replay ends with:

    VERIFIED: Z(12,18,3,3)=108
    ALL MUTATION TESTS PASSED
    PACKAGE VERIFICATION PASSED

For arXiv, select main.tex as the primary TeX file if prompted.
