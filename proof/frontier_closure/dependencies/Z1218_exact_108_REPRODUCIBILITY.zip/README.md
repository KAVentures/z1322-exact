# Exact value of `Z(12,18;3,3)`

This ancillary archive contains the complete reproducibility package for

\[
\boxed{Z(12,18;3,3)=108}.
\]

## One-command exact replay

From a clean extraction:

```bash
./verify.sh
```

The command:

1. verifies every file listed in `SHA256SUMS.txt`;
2. checks the explicit 108-one witness;
3. replays 303 exact certificates proving `Z(12,17;3,3) <= 103`;
4. replays 51 exact certificates proving `Z(11,18;3,3) <= 101`;
5. replays all four exhaustive 109-edge terminal cases;
6. compares deterministic proof statistics with the reference report; and
7. runs adversarial mutation tests that must be rejected.

A successful run ends with:

```text
VERIFIED: Z(12,18,3,3)=108
ALL MUTATION TESTS PASSED
PACKAGE VERIFICATION PASSED
```

Set `JOBS=1 ./verify.sh` for a sequential replay. The verifier uses only Python's
standard library and exact arithmetic; no LP, MILP, SAT solver, floating-point
infeasibility result, or network access is used.

## Proof contents

- `verify_all_exact.py` - trusted exact checker.
- `certificates/z1217/` - 303 neighboring-bound certificates.
- `certificates/z1118/` - 51 neighboring-bound certificates.
- `certificates/z1218/` - four final exhaustive-case certificates.
- `data/` - explicit 108-one witness and column supports.
- `mutation_tests.py` - negative-control tests.
- `reports/` - reference replay report and log.
- `generators/` - optional, non-trusted discovery/regeneration scripts.
- `PROOF_NOTE.md` - detailed proof and certificate explanation.
- `STATUS.md` - claim boundary and review status.
- `SHA256SUMS.txt` - integrity manifest.

## Trust boundary

The load-bearing proof base consists of the Python standard library,
`verify_all_exact.py`, and the hashed witness/certificate data. The generator
scripts and reference logs are retained for transparency but are not trusted by
the checker.

The result is internally exactly verified but has not yet undergone independent
expert reproduction or peer review.
